﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Home_Page : Form
    {
        public Home_Page()
        {
            InitializeComponent();
        }

        private void users_click(object sender, EventArgs e)
        {
            Add_and_View_User avu = new Add_and_View_User();
            this.Hide();
            avu.Show();
        }

        private void materials_click(object sender, EventArgs e)
        {
            View_Maaterials vm = new View_Maaterials();
            this.Hide();
            vm.Show();
        }

        private void backbutton_Click(object sender, EventArgs e)
        {
            LoginPage lp = new LoginPage();
            this.Hide();
            lp.Show();
        }
    }
}
