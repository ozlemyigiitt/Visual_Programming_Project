﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class View_Maaterials : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Özlem\source\repos\WinFormsApp1\WinFormsApp1\stock_control.mdf;Integrated Security=True");

        public View_Maaterials()
        {
            InitializeComponent();
        }

        private void AddButton_click(object sender, EventArgs e)
        {
            Add_Material adm = new Add_Material();
            this.Hide();
            adm.Show();
        }

        private void DeleteButton_click(object sender, EventArgs e)
        {
            Delete_and_Edit_Material dem = new Delete_and_Edit_Material();
            this.Hide();
            dem.Show();
        }

        private void EditButton_click(object sender, EventArgs e)
        {
            Delete_and_Edit_Material dem = new Delete_and_Edit_Material();
            this.Hide();
            dem.Show();
        }

        private void View_Maaterials_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();

            }
            con.Open();
            display();
        }
        public void display()
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from materials";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Home_Page hp = new Home_Page();
            this.Hide();
            hp.Show();
        }
    }
}
