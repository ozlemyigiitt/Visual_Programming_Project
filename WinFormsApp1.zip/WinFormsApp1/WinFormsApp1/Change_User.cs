﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Change_User : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Özlem\source\repos\WinFormsApp1\WinFormsApp1\stock_control.mdf;Integrated Security=True");

        public Change_User()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText= "Update registration Set UserName='" + textBox1.Text + "',Password='" + textBox2.Text + "',NameSurname='" + textBox3.Text + "',PhoneNumber='" + textBox4.Text + "',AuthorityLevel='" + comboBox1.SelectedItem + "' Where Id='" + textBox6.Text + "'";
            
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("User Update Successfully");

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Add_and_View_User avu = new Add_and_View_User();
            this.Hide();
            avu.Show();
        }
    }
}
