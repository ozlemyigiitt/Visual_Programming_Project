﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Delete_User : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Özlem\source\repos\WinFormsApp1\WinFormsApp1\stock_control.mdf;Integrated Security=True");

        public Delete_User()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Delete_User_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();

            }
            con.Open();
         
        }

        private void Delete_User_Load_1(object sender, EventArgs e)
        {

        }

        private void D(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();

            }
            con.Open();

            int id;
            id = Convert.ToInt32(textBox1.Text);
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from registration where Id=" + id + "";
            cmd.ExecuteNonQuery();

            MessageBox.Show("User Deletion Successfully");


        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Add_and_View_User avu = new Add_and_View_User();
            this.Hide();
            avu.Show();
        }
    }
}
