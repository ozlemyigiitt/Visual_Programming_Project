﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Delete_and_Edit_Material : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Özlem\source\repos\WinFormsApp1\WinFormsApp1\stock_control.mdf;Integrated Security=True");

        public Delete_and_Edit_Material()
        {
            InitializeComponent();
        }

        private void Delete_and_Edit_Material_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void EditButton_click(object sender, EventArgs e)
        {
           

            SqlCommand cmd2 = con.CreateCommand();
            cmd2.CommandType = CommandType.Text;
            cmd2.CommandText = "Update materials Set MaterialName='" + textBox3.Text + "',MaterialType='" + textBox4.Text + "',Price='" + textBox10.Text + "',StockQuantity='" + textBox9.Text + "',MaterialCondition='" + comboBox3.SelectedItem + "',StockDate='" + dateTimePicker1.Value.Date + "',MaterialLocation='" + comboBox2.SelectedItem + "' Where Id='" + textBox2.Text + "'";
            con.Open();
            cmd2.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Material Update Successfully");

        }

        private void DeleteButton_click(object sender, EventArgs e)
        {
            
            int id;
            id = Convert.ToInt32(textBox1.Text);
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from materials where Id=" + id + "";
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Material Deletion Successfully");

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            View_Maaterials vm = new View_Maaterials();
            this.Hide();
            vm.Show();
        }
    }
}
