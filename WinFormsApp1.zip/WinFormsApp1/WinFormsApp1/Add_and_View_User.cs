﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Add_and_View_User : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Özlem\source\repos\WinFormsApp1\WinFormsApp1\stock_control.mdf;Integrated Security=True");

        public Add_and_View_User()
        {
            InitializeComponent();
        }

        private void CreateButton_click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from registration where UserName='" + textBox1.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                int i = Convert.ToInt32(dt.Rows.Count.ToString());
                if (i == 0)
                {
                    SqlCommand cmd2 = con.CreateCommand();
                    cmd2.CommandType = CommandType.Text;
                    cmd2.CommandText = "insert into registration values('" + textBox.Text + "','" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + comboBox1.SelectedItem + "')";
                    cmd2.ExecuteNonQuery();

                    textBox.Text = "";
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                    comboBox1.SelectedItem = "";
                    display();
                    MessageBox.Show("User Record Inserted Successfully");
                }

                else
                {
                    MessageBox.Show("This Username Already Registered Please Choose Another");
                }
            }
            catch (Exception)
            {

                MessageBox.Show("There is a User with This ID...");

            }


        }
        private void Form2_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();

            }
            con.Open();
            display();
        }
        public void display()
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from registration";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void DeleteButton_click(object sender, EventArgs e)
        {
            Delete_User du = new Delete_User();
            this.Hide();
            du.Show();
        }

        private void ChangeButton_click(object sender, EventArgs e)
        {
            Change_User cu = new Change_User();
            this.Hide();
            cu.Show();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Home_Page hp = new Home_Page();
            this.Hide();
            hp.Show();
        }
    }
}
