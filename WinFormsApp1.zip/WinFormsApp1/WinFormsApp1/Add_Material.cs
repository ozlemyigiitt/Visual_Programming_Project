﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Add_Material : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Özlem\source\repos\WinFormsApp1\WinFormsApp1\stock_control.mdf;Integrated Security=True");

        public Add_Material()
        {
            InitializeComponent();
        }

        private void Add_Material_Load(object sender, EventArgs e)
        {

        }


        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void CleanButton_click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox6.Clear();
            textBox1.Focus();

        }

        private void SaveButton_click(object sender, EventArgs e)
        {
            SqlCommand cmd2 = con.CreateCommand();
            cmd2.CommandType = CommandType.Text;
            cmd2.CommandText = "insert into materials values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox6.Text + "','" + comboBox1.SelectedItem + "','" + dateTimePicker1.Value.Date+ "','" + comboBox2.SelectedItem + "')";
            con.Open();
            cmd2.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Material Record Inserted Successfully");

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            View_Maaterials vm = new View_Maaterials();
            this.Hide();
            vm.Show();
        }
    }
}
